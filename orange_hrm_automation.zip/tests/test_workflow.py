import time
from base.base_driver import init_driver
from pages.login_page import LoginPage
from pages.dashboard_page import DashboardPage
from pages.pim_page import PimPage

def test_orangehrm_workflow():
    driver = init_driver()
    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
    time.sleep(3)

    login_page = LoginPage(driver)
    login_page.enter_username("Admin")
    login_page.enter_password("admin123")
    login_page.click_login()
    time.sleep(3)

    dashboard = DashboardPage(driver)
    dashboard.go_to_pim()
    time.sleep(2)

    pim = PimPage(driver)
    employees = [("John", "Doe"), ("Jane", "Smith"), ("Alice", "Brown")]
    for first, last in employees:
        pim.click_add_employee()
        time.sleep(2)
        pim.enter_employee_details(first, last)
        pim.save_employee()
        time.sleep(2)

    pim.go_to_employee_list()
    time.sleep(2)
    for first, last in employees:
        full_name = f"{first} {last}"
        if pim.verify_employee(full_name):
            print(f"{full_name} Verified")
        else:
            print(f"{full_name} NOT FOUND")

    dashboard.logout()
    time.sleep(2)
    driver.quit()