from selenium.webdriver.common.by import By

class PimPage:
    def __init__(self, driver):
        self.driver = driver
        self.add_button = (By.XPATH, "//button[text()=' Add ']")
        self.first_name_input = (By.NAME, "firstName")
        self.last_name_input = (By.NAME, "lastName")
        self.save_button = (By.XPATH, "//button[@type='submit']")
        self.employee_list_button = (By.LINK_TEXT, "Employee List")
        self.name_column = (By.XPATH, "//div[@class='oxd-table-body']//div[@role='row']")

    def click_add_employee(self):
        self.driver.find_element(*self.add_button).click()

    def enter_employee_details(self, first_name, last_name):
        self.driver.find_element(*self.first_name_input).send_keys(first_name)
        self.driver.find_element(*self.last_name_input).send_keys(last_name)

    def save_employee(self):
        self.driver.find_element(*self.save_button).click()

    def go_to_employee_list(self):
        self.driver.find_element(*self.employee_list_button).click()

    def verify_employee(self, name):
        rows = self.driver.find_elements(*self.name_column)
        for row in rows:
            if name in row.text:
                print("Name Verified:", name)
                return True
        return False